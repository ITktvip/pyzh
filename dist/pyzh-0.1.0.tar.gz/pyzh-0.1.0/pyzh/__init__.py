# -*- coding: utf-8 -*-

__version__ = '0.0.1'
__author__ = 'Tech#6'

# 导入所有模块
from . import 内置函数
from . import 文件操作
from . import 数值运算
from . import 类型转换
from . import 集合操作
from . import 序列操作
from . import 函数方法
from . import 输入输出
from . import 编译执行
from . import 对象类
from . import 对象属性
from . import 逻辑判断
from . import 异常处理
from . import 迭代生成
from . import 魔法方法
from . import 工具函数